package org.spacehq.mc.protocol.data.game.world.block;

public enum BlockFace {
    DOWN,
    UP,
    NORTH,
    SOUTH,
    WEST,
    EAST,
    SPECIAL;
}
