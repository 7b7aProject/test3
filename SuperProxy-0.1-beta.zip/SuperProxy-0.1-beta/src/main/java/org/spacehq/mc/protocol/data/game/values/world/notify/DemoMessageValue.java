// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.world.notify;

public enum DemoMessageValue implements ClientNotificationValue {
  WELCOME,
  MOVEMENT_CONTROLS,
  JUMP_CONTROL,
  INVENTORY_CONTROL;
}
