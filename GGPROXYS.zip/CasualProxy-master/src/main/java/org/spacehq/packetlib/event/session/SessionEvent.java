// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.packetlib.event.session;

public interface SessionEvent
{
    void call(final SessionListener p0);
}
