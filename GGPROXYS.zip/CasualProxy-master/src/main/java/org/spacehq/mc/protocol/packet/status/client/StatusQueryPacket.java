package org.spacehq.mc.protocol.packet.status.client;

import org.spacehq.mc.protocol.packet.MinecraftPacket;
import org.spacehq.packetlib.io.NetInput;
import org.spacehq.packetlib.io.NetOutput;

import java.io.IOException;

public class StatusQueryPacket extends MinecraftPacket {
    public StatusQueryPacket() {
    }

    @Override
    public void read(NetInput in) throws IOException {
    }

    @Override
    public void write(NetOutput out) throws IOException {
    }
}
