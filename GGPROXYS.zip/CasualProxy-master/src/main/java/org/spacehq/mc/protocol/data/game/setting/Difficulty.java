package org.spacehq.mc.protocol.data.game.setting;

public enum Difficulty {
    PEACEFUL,
    EASY,
    NORMAL,
    HARD;
}
