// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.entity;

public enum MinecartType implements ObjectData {
  NORMAL,
  CHEST,
  POWERED,
  TNT,
  MOB_SPAWNER,
  HOPPER,
  COMMAND_BLOCK;
}
