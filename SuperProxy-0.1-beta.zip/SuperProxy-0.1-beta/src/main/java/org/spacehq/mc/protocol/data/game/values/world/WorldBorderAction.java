// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.world;

public enum WorldBorderAction {
  SET_SIZE,
  LERP_SIZE,
  SET_CENTER,
  INITIALIZE,
  SET_WARNING_TIME,
  SET_WARNING_BLOCKS;
}
