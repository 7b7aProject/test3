package org.spacehq.mc.protocol.data.game.setting;

public enum ChatVisibility {
    FULL,
    SYSTEM,
    HIDDEN;
}
