// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.scoreboard;

public enum ObjectiveAction {
  ADD,
  REMOVE,
  UPDATE;
}
