package org.spacehq.mc.protocol.data.game;

public enum MessageType {
    CHAT,
    SYSTEM,
    NOTIFICATION;
}
