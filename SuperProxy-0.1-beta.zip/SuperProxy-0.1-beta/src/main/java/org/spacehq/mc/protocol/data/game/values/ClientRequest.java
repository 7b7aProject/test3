// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values;

public enum ClientRequest {
  RESPAWN,
  STATS,
  OPEN_INVENTORY_ACHIEVEMENT;
}
