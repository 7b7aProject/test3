// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.window;

public enum ShiftClickItemParam implements WindowActionParam {
  LEFT_CLICK,
  RIGHT_CLICK;
}
