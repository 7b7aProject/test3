package xyz.yooniks.proxy.command.game;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.stream.Collectors;
import xyz.yooniks.proxy.command.basic.CommandExecutor;
import xyz.yooniks.proxy.command.basic.CommandInfo;
import xyz.yooniks.proxy.user.Optionable;
import xyz.yooniks.proxy.user.ProxyUser;
import xyz.yooniks.proxy.user.ProxyUserOptions;
import xyz.yooniks.proxy.user.ProxyUserOptions.BotMessageType;

@CommandInfo(
    name = "options",
    aliases = { "opcje", "useroptions" },
    description = "Добавляет возможность редактировать поля из интерфейса ProxyUserOptions с помощью отражения"
)
public class OptionsCommand implements CommandExecutor {

  @Override
  public void execute(ProxyUser executor, String[] args) {
    if (args.length < 1) {
      executor.sendMessage("&cPoprawne uzycie: &6!options [get/set/list] <имя поля> <значение>"
          + "&cField botjoinquitmessagetype принимает значения &6CHAT, ACTIONBAR, HIDDEN");
      return;
    }
    if (args[0].equalsIgnoreCase("list")) {
      executor.sendMessage("&cLista fieldow: &6\"" +
          Arrays.stream(executor.getOptions().getClass().getDeclaredFields())
              .map(Field::getName)
              .collect(Collectors.joining(", ")) + "\"");
      return;
    }
    if (args.length < 2) {
      executor.sendMessage("&cPoprawne uzycie: &6!options [get/set/list] <имя поля> <значение>"
          + "&cField botjoinquitmessagetype принимает значения &6CHAT, ACTIONBAR, HIDDEN");
      return;
    }
    try {
      final ProxyUserOptions userOptions = executor.getOptions();

      final Field field = userOptions
          .getClass().getDeclaredField(args[1]);
      field.setAccessible(true);

      final Optionable<Object> optionable;

      if (field.get(userOptions) instanceof Optionable) {
        optionable = (Optionable<Object>) field.get(userOptions);
      } else {
        executor.sendMessage(
                "&cЭто поле не реализует класс Optionable, не может быть изменено.");
        return;
      }

      if (args[0].equalsIgnoreCase("set")) {
        if (args.length < 3) {
          executor.sendMessage("&cВы не указали значение! "
                  + "&cPoprawne uzycie: &6!options set [имя поля] [значение]");
          return;
        }
        if (optionable.getValue() instanceof Integer) {
          int value;
          try {
            value = Integer.parseInt(args[2]);
          } catch (NumberFormatException exception) {
            executor.sendMessage("&cАргумент: &6" + args[2]
                    + " &cне может быть разбит на объект Integer, причина: " + exception
                    .getMessage());
            return;
          }
          optionable.setValue(value);
        } else if (optionable.getValue() instanceof Long) {
          long value;
          try {
            value = Long.parseLong(args[2]);
          } catch (NumberFormatException exception) {
            executor.sendMessage("&cАргумент: &6" + args[2]
                    + " &cон не мог быть разбит на объект Long, причина: " + exception
                    .getMessage());
            return;
          }
          optionable.setValue(value);
        } else if (optionable.getValue() instanceof Boolean) {
          boolean value;
          try {
            value = Boolean.parseBoolean(args[2]);
          } catch (NumberFormatException exception) {
            executor.sendMessage("&cАргумент: &6" + args[2]
                    + " &cне может быть разбит на логический объект, причина: " + exception
                    .getMessage());
            return;
          }
          optionable.setValue(value);
        }
        else if (optionable.getValue() instanceof BotMessageType) {
          final BotMessageType value = BotMessageType.getType(args[2]);
          if (value == BotMessageType.UNDETECTED) {
            executor.sendMessage("&cТакой тип сообщения (&6" + args[2] + "&c) не существует! \n"
                + "&cСписок типов сообщений: &6" + Arrays.stream(BotMessageType.values())
                .map(BotMessageType::name)
                .collect(Collectors.joining(", ")));
            return;
          }
          optionable.setValue(value);
        }
        else {
          optionable.setValue(args[2]);
        }
        executor.sendMessage("&7Задано значение для поля: &6" + field.getName()
                + "&7, на: &6" + optionable.getValue().toString());
      } else if (args[0].equalsIgnoreCase("get")) {
          try {
            executor.sendMessage("&7Значение поля &6" + args[1] + "&7: &6" + optionable.getValue());
          } catch (Exception exception) {
            executor.sendMessage(
                "&cНевозможно получить значение для field's: &6" + args[1] + "&c, причина: &6" + exception
                    .getMessage());
          }
      }
    } catch (NoSuchFieldException | IllegalAccessException exception) {
      if (exception instanceof IllegalAccessException) {
        exception.printStackTrace();
        return;
      }
      executor.sendMessage("&cПоле называется: &6" + args[1]
              + " &cего не существует! Используйте &6!options list &cскачать список полей");
    }
  }

}
