package org.spacehq.mc.protocol.data.game.world.block.value;

public enum ChestValueType implements BlockValueType {
    VIEWING_PLAYER_COUNT;
}
