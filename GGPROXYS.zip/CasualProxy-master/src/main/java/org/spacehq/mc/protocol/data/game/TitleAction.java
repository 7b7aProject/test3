package org.spacehq.mc.protocol.data.game;

public enum TitleAction {
    TITLE,
    SUBTITLE,
    ACTION_BAR,
    TIMES,
    CLEAR,
    RESET;
}
