// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game;

import java.util.Arrays;

public class NibbleArray3d {

  private byte[] data;

  public NibbleArray3d(final int size) {
    this.data = new byte[size >> 1];
  }

  public NibbleArray3d(final byte[] array) {
    this.data = array;
  }

  public byte[] getData() {
    return this.data;
  }

  public int get(final int x, final int y, final int z) {
    final int key = y << 8 | z << 4 | x;
    final int index = key >> 1;
    final int part = key & 0x1;
    return (part == 0) ? (this.data[index] & 0xF) : (this.data[index] >> 4 & 0xF);
  }

  public void set(final int x, final int y, final int z, final int val) {
    final int key = y << 8 | z << 4 | x;
    final int index = key >> 1;
    final int part = key & 0x1;
    if (part == 0) {
      this.data[index] = (byte) ((this.data[index] & 0xF0) | (val & 0xF));
    } else {
      this.data[index] = (byte) ((this.data[index] & 0xF) | (val & 0xF) << 4);
    }
  }

  public void fill(final int val) {
    for (int index = 0; index < this.data.length << 1; ++index) {
      final int ind = index >> 1;
      final int part = index & 0x1;
      if (part == 0) {
        this.data[ind] = (byte) ((this.data[ind] & 0xF0) | (val & 0xF));
      } else {
        this.data[ind] = (byte) ((this.data[ind] & 0xF) | (val & 0xF) << 4);
      }
    }
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || this.getClass() != o.getClass()) {
      return false;
    }
    final NibbleArray3d that = (NibbleArray3d) o;
    return Arrays.equals(this.data, that.data);
  }

  @Override
  public int hashCode() {
    return Arrays.hashCode(this.data);
  }
}
