package org.spacehq.mc.protocol.data.game.world.block.value;

public enum PistonValue implements BlockValue {
    DOWN,
    UP,
    SOUTH,
    WEST,
    NORTH,
    EAST;
}
