package org.spacehq.mc.protocol.data.game.window;

public enum CreativeGrabParam implements WindowActionParam {
    GRAB;
}
