package org.spacehq.mc.protocol.data.game.scoreboard;

public enum NameTagVisibility {
    ALWAYS,
    NEVER,
    HIDE_FOR_OTHER_TEAMS,
    HIDE_FOR_OWN_TEAM;
}
