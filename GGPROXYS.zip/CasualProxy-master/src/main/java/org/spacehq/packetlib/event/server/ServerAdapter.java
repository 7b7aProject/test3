// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.packetlib.event.server;

public class ServerAdapter implements ServerListener
{
    @Override
    public void serverBound(final ServerBoundEvent event) {
    }
    
    @Override
    public void serverClosing(final ServerClosingEvent event) {
    }
    
    @Override
    public void serverClosed(final ServerClosedEvent event) {
    }
    
    @Override
    public void sessionAdded(final SessionAddedEvent event) {
    }
    
    @Override
    public void sessionRemoved(final SessionRemovedEvent event) {
    }
}
