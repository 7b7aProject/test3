// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol;

import org.spacehq.packetlib.Session;

public interface ServerLoginHandler {

  void loggedIn(final Session p0);
}
