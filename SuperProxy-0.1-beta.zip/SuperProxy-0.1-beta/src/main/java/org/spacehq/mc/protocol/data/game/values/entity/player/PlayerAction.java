// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.entity.player;

public enum PlayerAction {
  START_DIGGING,
  CANCEL_DIGGING,
  FINISH_DIGGING,
  DROP_ITEM_STACK,
  DROP_ITEM,
  RELEASE_USE_ITEM;
}
