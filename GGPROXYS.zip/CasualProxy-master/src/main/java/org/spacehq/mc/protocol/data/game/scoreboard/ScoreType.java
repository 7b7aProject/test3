package org.spacehq.mc.protocol.data.game.scoreboard;

public enum ScoreType {
    INTEGER,
    HEARTS;
}
