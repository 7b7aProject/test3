package xyz.yooniks.proxy.helper;

public interface Builder<T> {

  T build();

}
