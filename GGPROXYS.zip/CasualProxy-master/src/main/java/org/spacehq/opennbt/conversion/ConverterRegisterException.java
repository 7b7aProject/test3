// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.opennbt.conversion;

public class ConverterRegisterException extends RuntimeException
{
    private static final long serialVersionUID = -2022049594558041160L;
    
    public ConverterRegisterException() {
    }
    
    public ConverterRegisterException(final String message) {
        super(message);
    }
    
    public ConverterRegisterException(final Throwable cause) {
        super(cause);
    }
    
    public ConverterRegisterException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
