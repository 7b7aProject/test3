// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.packetlib.event.server;

public interface ServerEvent {

  void call(final ServerListener p0);
}
