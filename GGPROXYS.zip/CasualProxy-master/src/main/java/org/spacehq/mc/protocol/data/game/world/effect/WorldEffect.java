package org.spacehq.mc.protocol.data.game.world.effect;

public interface WorldEffect {
}
