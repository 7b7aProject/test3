// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.auth.exception.property;

public class ProfileTextureException extends PropertyException {

  private static final long serialVersionUID = 1L;

  public ProfileTextureException() {
  }

  public ProfileTextureException(final String message) {
    super(message);
  }

  public ProfileTextureException(final String message, final Throwable cause) {
    super(message, cause);
  }

  public ProfileTextureException(final Throwable cause) {
    super(cause);
  }
}
