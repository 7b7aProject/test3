// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.entity;

public enum ModifierOperation {
  ADD,
  ADD_MULTIPLIED,
  MULTIPLY;
}
