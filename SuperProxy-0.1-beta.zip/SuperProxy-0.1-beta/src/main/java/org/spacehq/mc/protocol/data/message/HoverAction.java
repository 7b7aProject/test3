// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.message;

public enum HoverAction {
  SHOW_TEXT,
  SHOW_ITEM,
  SHOW_ACHIEVEMENT,
  SHOW_ENTITY;

  public static HoverAction byName(String name) {
    name = name.toLowerCase();
    for (final HoverAction action : values()) {
      if (action.toString().equals(name)) {
        return action;
      }
    }
    return null;
  }

  @Override
  public String toString() {
    return this.name().toLowerCase();
  }
}
