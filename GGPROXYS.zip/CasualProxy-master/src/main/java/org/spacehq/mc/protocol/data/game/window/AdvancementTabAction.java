package org.spacehq.mc.protocol.data.game.window;

public enum AdvancementTabAction {
    OPENED_TAB,
    CLOSED_SCREEN;
}
