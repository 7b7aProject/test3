package org.spacehq.mc.protocol.data.game.world.notify;

public interface ClientNotificationValue {
}
