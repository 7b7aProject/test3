package org.spacehq.mc.protocol.data.game.window;

public enum FillStackParam implements WindowActionParam {
    FILL;
}
