// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.setting;

public enum SkinPart {
  CAPE,
  JACKET,
  LEFT_SLEEVE,
  RIGHT_SLEEVE,
  LEFT_PANTS_LEG,
  RIGHT_PANTS_LEG,
  HAT;
}
