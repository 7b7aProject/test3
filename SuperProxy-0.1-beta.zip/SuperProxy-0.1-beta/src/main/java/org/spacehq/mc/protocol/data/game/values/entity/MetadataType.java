// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.entity;

public enum MetadataType {
  BYTE,
  SHORT,
  INT,
  FLOAT,
  STRING,
  ITEM,
  POSITION,
  ROTATION;
}
