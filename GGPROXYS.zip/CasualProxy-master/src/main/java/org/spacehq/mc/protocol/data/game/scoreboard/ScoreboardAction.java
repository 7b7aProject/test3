package org.spacehq.mc.protocol.data.game.scoreboard;

public enum ScoreboardAction {
    ADD_OR_UPDATE,
    REMOVE;
}
