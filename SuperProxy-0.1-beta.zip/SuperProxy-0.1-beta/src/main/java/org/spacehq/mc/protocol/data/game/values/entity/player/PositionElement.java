// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.entity.player;

public enum PositionElement {
  X,
  Y,
  Z,
  PITCH,
  YAW;
}
