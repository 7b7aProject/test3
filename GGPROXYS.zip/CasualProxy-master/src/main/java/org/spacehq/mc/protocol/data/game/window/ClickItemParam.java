package org.spacehq.mc.protocol.data.game.window;

public enum ClickItemParam implements WindowActionParam {
    LEFT_CLICK,
    RIGHT_CLICK;
}
