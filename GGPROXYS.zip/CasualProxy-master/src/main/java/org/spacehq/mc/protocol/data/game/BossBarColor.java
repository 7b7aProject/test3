package org.spacehq.mc.protocol.data.game;

public enum BossBarColor {
    PINK,
    CYAN,
    RED,
    LIME,
    YELLOW,
    PURPLE,
    WHITE;
}
