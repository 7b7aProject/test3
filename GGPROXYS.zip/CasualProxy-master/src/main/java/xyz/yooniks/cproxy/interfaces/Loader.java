package xyz.yooniks.cproxy.interfaces;

public interface Loader {

    abstract void onLoad();

}
