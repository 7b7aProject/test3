package org.spacehq.mc.protocol.data.game.world.notify;

public enum EnterCreditsValue implements ClientNotificationValue {
    SEEN_BEFORE,
    FIRST_TIME;
}
