// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.window.property;

public enum FurnaceProperty {
  BURN_TIME,
  CURRENT_ITEM_BURN_TIME,
  COOK_TIME,
  TOTAL_COOK_TIME;
}
