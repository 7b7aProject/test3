package org.spacehq.mc.protocol.data.game.entity.type.object;

public enum MinecartType implements ObjectData {
    NORMAL,
    CHEST,
    POWERED,
    TNT,
    MOB_SPAWNER,
    HOPPER,
    COMMAND_BLOCK;
}
