package org.spacehq.mc.protocol.data;

public enum SubProtocol {
    HANDSHAKE,
    LOGIN,
    GAME,
    STATUS;
}
