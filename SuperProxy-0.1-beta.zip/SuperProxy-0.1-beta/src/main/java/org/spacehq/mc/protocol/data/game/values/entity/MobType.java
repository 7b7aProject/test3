// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.entity;

public enum MobType {
  ARMOR_STAND,
  CREEPER,
  SKELETON,
  SPIDER,
  GIANT_ZOMBIE,
  ZOMBIE,
  SLIME,
  GHAST,
  ZOMBIE_PIGMAN,
  ENDERMAN,
  CAVE_SPIDER,
  SILVERFISH,
  BLAZE,
  MAGMA_CUBE,
  ENDER_DRAGON,
  WITHER,
  BAT,
  WITCH,
  ENDERMITE,
  GUARDIAN,
  PIG,
  SHEEP,
  COW,
  CHICKEN,
  SQUID,
  WOLF,
  MOOSHROOM,
  SNOWMAN,
  OCELOT,
  IRON_GOLEM,
  HORSE,
  RABBIT,
  VILLAGER;
}
