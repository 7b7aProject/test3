// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.world.block;

public enum UpdatedTileType {
  MOB_SPAWNER,
  COMMAND_BLOCK,
  BEACON,
  SKULL,
  FLOWER_POT,
  BANNER;
}
