// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.world.effect;

public enum SmokeEffectData implements WorldEffectData {
  SOUTH_EAST,
  SOUTH,
  SOUTH_WEST,
  EAST,
  UP,
  WEST,
  NORTH_EAST,
  NORTH,
  NORTH_WEST;
}
