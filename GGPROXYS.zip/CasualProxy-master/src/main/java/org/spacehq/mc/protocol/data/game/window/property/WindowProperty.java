package org.spacehq.mc.protocol.data.game.window.property;

public interface WindowProperty {
}
