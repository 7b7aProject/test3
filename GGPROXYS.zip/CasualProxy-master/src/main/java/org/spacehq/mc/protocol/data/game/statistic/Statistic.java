package org.spacehq.mc.protocol.data.game.statistic;

public interface Statistic {
}
