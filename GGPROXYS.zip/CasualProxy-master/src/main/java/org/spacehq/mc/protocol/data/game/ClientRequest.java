package org.spacehq.mc.protocol.data.game;

public enum ClientRequest {
    RESPAWN,
    STATS;
}
