package org.spacehq.mc.protocol.data.game.entity.type.object;

public interface ObjectData {
}
