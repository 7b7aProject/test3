package org.spacehq.mc.protocol.data.game.entity.player;

public enum Hand {
    MAIN_HAND,
    OFF_HAND;
}
