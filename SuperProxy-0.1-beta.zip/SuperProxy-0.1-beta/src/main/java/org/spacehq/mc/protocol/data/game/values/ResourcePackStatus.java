// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values;

public enum ResourcePackStatus {
  SUCCESSFULLY_LOADED,
  DECLINED,
  FAILED_DOWNLOAD,
  ACCEPTED;
}
