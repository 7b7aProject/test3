# CasualProxy
Proxy created using mcprotocollib for 1.8.8 version.
by: yooniks <3
