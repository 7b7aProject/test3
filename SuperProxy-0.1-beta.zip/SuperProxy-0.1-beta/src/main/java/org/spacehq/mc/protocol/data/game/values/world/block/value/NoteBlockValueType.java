// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.world.block.value;

public enum NoteBlockValueType implements BlockValueType {
  HARP,
  DOUBLE_BASS,
  SNARE_DRUM,
  HI_HAT,
  BASS_DRUM;
}
