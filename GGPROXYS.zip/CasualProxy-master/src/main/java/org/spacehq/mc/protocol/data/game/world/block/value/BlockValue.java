package org.spacehq.mc.protocol.data.game.world.block.value;

public interface BlockValue {
}
