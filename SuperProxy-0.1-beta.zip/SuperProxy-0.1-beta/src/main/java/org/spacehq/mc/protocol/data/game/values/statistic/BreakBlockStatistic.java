// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.statistic;

public class BreakBlockStatistic implements Statistic {

  private int id;

  public BreakBlockStatistic(final int id) {
    this.id = id;
  }

  public int getId() {
    return this.id;
  }
}
