package org.spacehq.mc.protocol.data.game.window;

public interface WindowActionParam {
}
