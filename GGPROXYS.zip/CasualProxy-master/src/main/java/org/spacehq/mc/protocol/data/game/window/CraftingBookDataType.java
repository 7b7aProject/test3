package org.spacehq.mc.protocol.data.game.window;

public enum CraftingBookDataType {
    DISPLAYED_RECIPE,
    CRAFTING_BOOK_STATUS;
}
