// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.window.property;

public enum AnvilProperty {
  MAXIMUM_COST;
}
