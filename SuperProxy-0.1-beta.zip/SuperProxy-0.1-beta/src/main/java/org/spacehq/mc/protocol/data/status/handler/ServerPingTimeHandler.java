// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.status.handler;

import org.spacehq.packetlib.Session;

public interface ServerPingTimeHandler {

  void handle(final Session p0, final long p1);
}
