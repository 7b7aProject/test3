package org.spacehq.mc.protocol.data.game.entity.player;

public enum InteractAction {
    INTERACT,
    ATTACK,
    INTERACT_AT;
}
