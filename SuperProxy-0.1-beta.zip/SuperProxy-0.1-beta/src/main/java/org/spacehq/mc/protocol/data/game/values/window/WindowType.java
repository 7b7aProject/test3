// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.window;

public enum WindowType {
  GENERIC_INVENTORY,
  ANVIL,
  BEACON,
  BREWING_STAND,
  CHEST,
  CRAFTING_TABLE,
  DISPENSER,
  DROPPER,
  ENCHANTING_TABLE,
  FURNACE,
  HOPPER,
  VILLAGER,
  HORSE;
}
