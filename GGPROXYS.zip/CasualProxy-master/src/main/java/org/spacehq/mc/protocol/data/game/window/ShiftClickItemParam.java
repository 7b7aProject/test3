package org.spacehq.mc.protocol.data.game.window;

public enum ShiftClickItemParam implements WindowActionParam {
    LEFT_CLICK,
    RIGHT_CLICK;
}
