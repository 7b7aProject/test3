package org.spacehq.mc.protocol.data.game.scoreboard;

public enum CollisionRule {
    ALWAYS,
    NEVER,
    PUSH_OTHER_TEAMS,
    PUSH_OWN_TEAM;
}
