package org.spacehq.mc.protocol.data.game.entity.player;

public enum PositionElement {
    X,
    Y,
    Z,
    PITCH,
    YAW;
}
