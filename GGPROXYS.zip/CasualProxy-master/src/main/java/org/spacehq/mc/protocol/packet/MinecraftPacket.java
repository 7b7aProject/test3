package org.spacehq.mc.protocol.packet;

import org.spacehq.mc.protocol.util.ObjectUtil;
import org.spacehq.packetlib.packet.Packet;

public abstract class MinecraftPacket implements Packet {
    @Override
    public boolean isPriority() {
        return false;
    }

    @Override
    public String toString() {
        return ObjectUtil.toString(this);
    }
}
