package org.spacehq.mc.protocol.data.game.world.notify;

public enum DemoMessageValue implements ClientNotificationValue {
    WELCOME,
    MOVEMENT_CONTROLS,
    JUMP_CONTROL,
    INVENTORY_CONTROL;
}
