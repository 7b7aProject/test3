package org.spacehq.mc.protocol.data.game.scoreboard;

public enum ObjectiveAction {
    ADD,
    REMOVE,
    UPDATE;
}
