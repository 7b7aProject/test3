package org.spacehq.mc.protocol.data.game.scoreboard;

public enum TeamAction {
    CREATE,
    REMOVE,
    UPDATE,
    ADD_PLAYER,
    REMOVE_PLAYER;
}
