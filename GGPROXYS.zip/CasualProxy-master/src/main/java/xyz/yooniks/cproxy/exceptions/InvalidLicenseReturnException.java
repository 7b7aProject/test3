package xyz.yooniks.cproxy.exceptions;

public class InvalidLicenseReturnException extends RuntimeException {

    public InvalidLicenseReturnException(String message) {
        super(message);
    }
}
