// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.mc.protocol.data.game.values.scoreboard;

public enum TeamAction {
  CREATE,
  REMOVE,
  UPDATE,
  ADD_PLAYER,
  REMOVE_PLAYER;
}
