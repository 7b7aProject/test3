package org.spacehq.mc.protocol.data.handshake;

public enum HandshakeIntent {
    STATUS,
    LOGIN;
}
