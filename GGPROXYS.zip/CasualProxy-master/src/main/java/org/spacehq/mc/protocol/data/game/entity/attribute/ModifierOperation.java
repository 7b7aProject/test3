package org.spacehq.mc.protocol.data.game.entity.attribute;

public enum ModifierOperation {
    ADD,
    ADD_MULTIPLIED,
    MULTIPLY;
}
