package org.spacehq.mc.protocol.data.game.entity.type;

public enum GlobalEntityType {
    LIGHTNING_BOLT;
}
