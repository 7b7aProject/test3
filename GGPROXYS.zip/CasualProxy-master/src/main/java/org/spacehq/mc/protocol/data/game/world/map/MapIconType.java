package org.spacehq.mc.protocol.data.game.world.map;

public enum MapIconType {
    WHITE_ARROW,
    GREEN_ARROW,
    RED_ARROW,
    BLUE_ARROW,
    WHITE_CROSS,
    RED_POINTER,
    WHITE_CIRCLE,
    SMALL_WHITE_CIRCLE,
    MANSION,
    TEMPLE,
    UNUSED_10,
    UNUSED_11,
    UNUSED_12,
    UNUSED_13,
    UNUSED_14,
    UNUSED_15;
}
