package xyz.yooniks.cproxy.enums;

public enum MacroType {

    BOT,
    PLAYER;

}
