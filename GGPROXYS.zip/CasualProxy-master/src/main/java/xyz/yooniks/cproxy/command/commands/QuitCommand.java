package xyz.yooniks.cproxy.command.commands;

import xyz.yooniks.cproxy.command.Command;
import xyz.yooniks.cproxy.enums.Group;
import xyz.yooniks.cproxy.objects.Player;

public class QuitCommand extends Command {

    public QuitCommand() {
        super("quit", "Выход (отключает вас от сервера)", ",quit",
                Group.GRACZ, "wyjdz", "left", "leave", "q");
    }

    @Override
    public void onCommand(Player p, Command command, String[] args) {
        if (p.isConnected()) {
            p.getSessionConnect().disconnect("Вас оотключило с помощью команды");
            p.setConnected(false);
            p.setSessionConnect(null);
            p.setLastPacketMs(0L);
            p.setLastPacketMs(0L);
            p.sendMessage("$p &aRozlaczono przy uzyciu komendy! :)");
        } else {
            p.sendMessage("$p &b Вы не подключены не к серверам!");
        }
    }
}
