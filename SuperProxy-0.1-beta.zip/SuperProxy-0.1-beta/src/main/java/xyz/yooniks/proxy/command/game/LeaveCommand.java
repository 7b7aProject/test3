package xyz.yooniks.proxy.command.game;

import xyz.yooniks.proxy.SuperProxyImpl;
import xyz.yooniks.proxy.command.basic.CommandExecutor;
import xyz.yooniks.proxy.command.basic.CommandInfo;
import xyz.yooniks.proxy.user.ProxyUser;

@CommandInfo(
    name = "leave",
    aliases = { "quit", "rozlacz", "wyjdz" },
    description = "Отключает клиент от подключенного к серверу"
)
public class LeaveCommand implements CommandExecutor {

  @Override
  public void execute(ProxyUser executor, String[] args) {
    executor.asPlayer().ifPresent(player ->
        executor.getFakeSession().ifPresentOrElse((session) -> {
              session.getPacketProtocol().clearPackets();
              session.disconnect("Disconnected by command");

              player.teleport(SuperProxyImpl.SPAWN_LOCATION);
              player.sendMessage("&6отключение &7клиента.");
            }, () ->
                player.sendMessage("&cВы не подключены ни к одному серверу!")
        )
    );
  }

}
